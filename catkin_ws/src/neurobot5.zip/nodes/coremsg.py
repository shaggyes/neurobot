#!/usr/bin/env python
import sys
import time
import rospy
import datetime
import serial
# import os
from subprocess import call
from std_msgs.msg import Int32MultiArray  # meuserements
from std_msgs.msg import String  # error msg
from sensor_msgs.msg import BatteryState  # battery
from sensor_msgs.msg import LaserScan  # Ultrasonic Scan 6x
from smbus import SMBus
addri2c = 0x8
bus = SMBus(1)

port = serial.Serial("/dev/ttyAMA0", baudrate=57600, timeout=3.0)


def filter(sensor, prev, filtConst):
	return ((sensor-prev)*filtConst + prev)


def mainfunc():
	global port, bus
	print('step1')
	
	rospy.init_node('nbcoredata', anonymous=True)
	pubM = rospy.Publisher('neurobotmeasure', Int32MultiArray, queue_size=1)
	pubB = rospy.Publisher('neurobotbattery', BatteryState, queue_size=1)
	pubUS = rospy.Publisher('neurobotsonarscan', LaserScan, queue_size=1)
	# pubError = rospy.Publisher('neuroboterror', String, queue_size=1)
	rate = rospy.Rate(10) # 10hz
	CoreMeasure = Int32MultiArray()
	CoreMeasure.data = []
	CoreBat = BatteryState()
	CoreScan = LaserScan()
	CoreScan.range_min = 0.02
	CoreScan.range_max = 2.56
	CoreScan.scan_time = 0.3
	CoreScan.angle_increment = 1.04719
	CoreScan.angle_min = -2.09439
	CoreScan.angle_max = 3.1415
	# Error = String()
	temporarystr = port.read(12)
	prevVoltage = int( (ord(temporarystr[2])*0.0316+7.244)*1000)
	batteryS = int( prevVoltage//3200)
	if batteryS < 1: batteryS = 1
	speedRightPrev = 0
	speedRight = 0
	speedLeftPrev = 0
	speedLeft = 0
	print('step2')
	
	while not rospy.is_shutdown():
		# print('step3')
		
		if port.inWaiting:

			serialstr = []
			serialstr = port.read(12)
			i2cstr = []
			for i in range(7):
				i2cstr.append(bus.read_byte(addri2c))
			voltage = int( (ord(serialstr[2])*0.0316 + 7.244)  *1000) # in mV
			prevVoltage = int(filter(voltage, prevVoltage, 0.1))
			current = int((-0.0004*(ord(serialstr[3])**2)+(0.0697*ord(serialstr[3]))-0.5384) * 1000) # in mA  
			tempStr = os.popen('vcgencmd measure_temp').readline()
			tempStr = tempStr.replace("temp=","")
			tempStr = tempStr.replace(".","")
			tempStr = tempStr.replace("'C\n","")
			tempPi = int(tempStr)/10
			enc1 = ord(serialstr[5])
			enc2 = ord(serialstr[4])
			if (  ( ((speedRightPrev < 20)or(speedRightPrev > 245)) or (speedRight < 0) )and(enc1>100)  ): speedRight = -(256-enc1)
			else: speedRight = enc1
			speedRightPrev = enc1
			if (  ( ((speedLeftPrev < 20)or(speedLeftPrev > 245)) or (speedLeft < 0) )and(enc2>100)  ): speedLeft = -(256-enc2)
			else: speedLeft = enc2
			speedLeftPrev = enc2
			VperS = voltage/(1000*batteryS)
			bat0l0 = int(-(188.32*(VperS**3))+(2141.2*(VperS**2))-(7964.4*VperS)+9732.7)

			CoreMeasure.data = [ord(serialstr[0]), i2cstr[0], prevVoltage, bat0l0, current, tempPi, speedLeft, speedRight] # [ But1, But2, Voltage, Charge%, Current, Temp, EncoderTicks1, Encoder2 ]
			CoreScan.ranges = [i2cstr[1]/100, i2cstr[2]/100, i2cstr[5]/100, i2cstr[6]/100, i2cstr[4]/100, i2cstr[3]/100]
			CoreBat.voltage = voltage/1000
			CoreBat.current = current/1000
			CoreBat.percentage = bat0l0/100

			#rospy.loginfo(CoreMeasure)
			pubM.publish(CoreMeasure)
			pubB.publish(Corebat)
			pubUS.publish(CoreScan)
			#Error.data = "none"
			#pubError.publish(Error)
		rate.sleep()



if __name__ == '__main__':
    try:
        mainfunc()
    except rospy.ROSInterruptException:
        pass
