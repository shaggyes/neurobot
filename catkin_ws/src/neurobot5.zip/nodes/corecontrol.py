#!/usr/bin/env python
import sys
import time
import rospy
import datetime
import serial
import os
import tf
import math
from math import sin, cos, pi
from subprocess import call
from std_msgs.msg import Int32MultiArray # meuserements
from std_msgs.msg import Float32MultiArray # params
from std_msgs.msg import String #error msg
from nav_msgs.msg import Odometry # odometry
from geometry_msgs.msg import TwistStamped # cmd_vel
from geometry_msgs.msg import Point, Pose, Quaternion, Twist, Vector3
from sensor_msgs.msg import LaserScan # Ultrasonic Scan 6x
Timing = 10
dt = 1/Timing
PoseXYth = [0.00001, 0, 0]
halftimespeed = 0 #speed filter
koefBreak = 2.5 # koef of breaking system to AOA
margin = 0.05 # in m for AOA
PIDpreverrM1 = 0 # for pid
PIDintegralM1 = 0
PIDpreverrM2 = 0
PIDintegralM2 = 0

port = serial.Serial("/dev/ttyAMA0", baudrate=57600, timeout=3.0)

#command_list = [0, 0, 0] # left, right, AOAon/off
recv_cmd_vel = TwistStamped()
recv_params = [0, 0, 0.12, 0.268, 0.00406, 0.3, 1, 0.1, 0.1, 0.1, 1, 2] # AOA, PWR, wheelDia, wheelBase, EncToSpeed, MaxSpeed, PorV, PID.P, PID.I, PID.D, FullDrive, MaxLagInS
two_encoders = [0, 0, 0, 0, 0, 0, 0, 0] # Nah, Nah, Nah, Nah, Nah, Nah, LeftTicks, RightTicks

def callback_params(data):
    global recv_params
    #rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data.data)
    recv_params = data.data
def callback_encoders(data):
    global two_encoders
    two_encoders = data.data

def position(dt, vx, vy, vth, x, y, th):
	delta_x = (vx * cos(th) - vy * sin(th)) * dt
	delta_y = (vx * sin(th) + vy * cos(th)) * dt
	delta_th = vth * dt
	x += delta_x
	y += delta_y
	th += delta_th
	# since all odometry is 6DOF we'll need a quaternion created from yaw
	odom_quat = tf.transformations.quaternion_from_euler(0, 0, th)
	return Pose(Point(x, y, 0.), Quaternion(*odom_quat))

def filter(sensor, prev, filtConst):
	return ((sensor-prev)*filtConst + prev)

def AOA(speedy, cmdSpeed, cmdAngle, dist1, dist2):
	global halftimespeed, koefBreak, margin, dt
	halftimespeed = filter(speedy, halftimespeed, 0.5)
	
	if (speedy > 0):
		if (speedy*dt) > (dist1-margin)/koefBreak:
			cmdSpeed = 0
	elif (speedy < 0):
		if (-speedy*dt) > (dist2-margin)/koefBreak:
			cmdSpeed = 0
	return [cmdSpeed, cmdAngle]

def PID(error, integral, previous_error, limits, Kp, Ki, Kd):
	global dt
	integral = integral + error * dt
	derivative = (error - previous_error) / dt
	output = float(Kp * error + Ki * integral + Kd * derivative)*limits / 100
	previous_error = error
	if  (output > limits): output = limits
	elif (output < - limits): output = -limits
	return output, integral, previous_error

def SpeedSender(speed, angle, realSpeed, realAngle):
	global recv_params #drive, PorV, MaxSpeed, WheelBase, PIDs

	l = ((2*speed) - (angle * recv_params[3]))/2
	r = ((2*speed) + (angle * recv_params[3]))/2
	if (l > recv_params[5]): l = recv_params[5]
	if (l < -recv_params[5]): l = -recv_params[5]
	if (r > recv_params[5]): r = recv_params[5]
	if (r < -recv_params[5]): r = -recv_params[5]

	leftS = ((2*realSpeed) - (realAngle * recv_params[3]))/2
	rightS = ((2*realSpeed) + (realAngle * recv_params[3]))/2	

	if (recv_params[6] == 1):
		lout, PIDpreverrM1, PIDintegralM1 = PID(l-leftS, PIDintegralM1, PIDpreverrM1, 100, recv_params[7], recv_params[8], recv_params[9])
		rout, PIDpreverrM2, PIDintegralM2 = PID(r-rightS, PIDintegralM2, PIDpreverrM2, 100, recv_params[7], recv_params[8], recv_params[9])
	else:
		lout = int(recv_params[5]/l)*100
		rout = int(recv_params[5]/r)*100

	if (lout > 100): lout = 100
	if (lout < -100): lout = -100
	if (rout > 100): rout = 100
	if (rout < -100): rout = -100

	if (lout < 0):
		L = 60 - int(lout*0.51)
	else:
		L = int(lout*0.51)
	if (rout < 0):
		R = 60 - int(rout*0.51)
	else:
		R = int(rout*0.51)
	
	return str(chr(125+recv_params[10])+chr(L)+chr(R))

def mainfunc():
	global port, recv_cmd_vel, Timing, dt, recv_params, two_encoders, PoseXYth, UartCmd
	print('step1')
	
	rospy.init_node('nbcorecontrol', anonymous=True)
	pubO = rospy.Publisher('odom', Odometry, queue_size=1)
	#pubError = rospy.Publisher('neuroboterror', String, queue_size=1)
	rate = rospy.Rate(Timing) # 10hz
	CoreOdom = Odometry()	
	CoreOdom.header.frame_id = "odom"
	CoreOdom.child_frame_id = "base_link"
	SonarScan = LaserScan()
	PultSpeed = TwistStamped()
	while not rospy.is_shutdown():
		
		rospy.Subscriber('neurobotmeasure', Int32MultiArray, callback_encoders)
		rospy.Subscriber('neurobotparams', Float32MultiArray, callback_params)		
		velocityLeft = two_encoders[6]*recv_params[4]*Timing
		velocityRight = two_encoders[7]*recv_params[4]*Timing
		speedBase = (velocityLeft + velocityRight)/2
		angleSpeed = (velocityRight - velocityLeft)/recv_params[3]
		CoreOdom.header.stamp = rospy.Time.now()
    		CoreOdom.pose.pose = position(dt, speedBase, 0, angleSpeed, PoseXYth[0], PoseXYth[1], PoseXYth[2])
    		CoreOdom.twist.twist = Twist(Vector3(speedBase, 0, 0), Vector3(0, 0, angleSpeed))
		pubO.publish(CoreOdom)
		rospy.Subscriber('neurobotsonarscan', LaserScan, SonarScan)
		sonars = SonarScan.ranges
		#sonars[2] = filter
		rospy.Subscriber('cmd_vel', TwistStamped, PultSpeed)
		pult_speed_cmd = [PultSpeed.twist.twist.linear.x, PultSpeed.twist.twist.angular.z] #speed, angle
		if ( (rospy.Time.now() - PultSpeed.header.stamp).to_sec() > recv_params[11] ):
			print("big lag")
			pult_speed_cmd[0] = 0
			pult_speed_cmd[1] = 0

		if (recv_params[0] == 1): #AOA on		
			pult_speed_cmd = AOA(speedBase, pult_speed_cmd[0], pult_speed_cmd[1], sonars[2], sonars[5])
		
		port.write(SpeedSender(pult_speed_cmd[0], pult_speed_cmd[1], speedBase, angleSpeed))

		if (recv_params[1] == 1): #shutdown now
			print("shutdown now")
			#call("sudo shutdown now", shell=True)
		rate.sleep()


if __name__ == '__main__':
    try:
        mainfunc()
    except rospy.ROSInterruptException:
        pass
