#!/bin/bash

roslaunch nebot_navigation amcl_demo.launch
