#!/bin/bash

sudo killall gzserver
sudo killall gzclient
sudo killall rviz
sudo killall roscore
sudo killall rosmaster

roslaunch nebot_gazebo nebot_world.launch
rosrun neurobot_virt1 nbcore.py
