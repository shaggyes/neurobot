#!/bin/bash
roslaunch nebot_navigation nebot_teleop.launch
