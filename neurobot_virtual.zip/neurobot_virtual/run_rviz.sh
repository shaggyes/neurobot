#!/bin/bash

#roslaunch mybot_description mybot_rviz.launch
roslaunch nebot_description nebot_rviz_amcl.launch 
